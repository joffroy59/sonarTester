Sonar PDF Report Plugin
=========================

This is the Sonar PDF Report Plugin.

Project homepage:
http://docs.codehaus.org/display/SONAR/PDF+Plugin

Issue tracking:
https://jira.codehaus.org/browse/SONARPLUGINS/component/14372

CI builds:
https://sonarplugins.ci.cloudbees.com/job/report-pdf
